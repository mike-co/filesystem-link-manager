using System;
using System.Threading.Tasks;
using Xunit;

namespace Enterprise.Tests
{
    /// <summary>
    /// PaymentProcessorTests contains unit tests
    /// </summary>
    public class PaymentProcessorTests
    {
        [Fact]
        public async Task Should_ReturnTrue_When_ValidInput()
        {
            // Arrange
            var input = "test";
            
            // Act
            var result = await ProcessAsync(input);
            
            // Assert
            Assert.True(result);
        }
        
        private async Task<bool> ProcessAsync(string input)
        {
            await Task.Delay(1);
            return !string.IsNullOrEmpty(input);
        }
    }
}