-- Database Migration
-- Generated on: 2025-09-09 21:30:20

USE [EnterpriseDb]
GO

-- Create tables
CREATE TABLE [dbo].[Users] (
    [Id] uniqueidentifier NOT NULL PRIMARY KEY DEFAULT NEWID(),
    [Name] nvarchar(255) NOT NULL,
    [Email] nvarchar(255) NOT NULL UNIQUE,
    [CreatedDate] datetime2 NOT NULL DEFAULT GETUTCDATE()
);

-- Insert sample data
INSERT INTO [dbo].[Users] ([Name], [Email])
VALUES ('Sample User', 'user@example.com');
